package menu.main;

import org.encog.engine.network.activation.ActivationLinear;
import org.encog.engine.network.activation.ActivationSigmoid;
import org.encog.engine.network.activation.ActivationStep;
import org.encog.ml.data.MLData;
import org.encog.ml.data.MLDataPair;
import org.encog.ml.data.MLDataSet;
import org.encog.ml.data.basic.BasicMLData;
import org.encog.ml.data.basic.BasicMLDataSet;
import org.encog.ml.train.MLTrain;
import org.encog.neural.networks.BasicNetwork;
import org.encog.neural.networks.layers.BasicLayer;
import org.encog.neural.networks.training.lma.LevenbergMarquardtTraining;
import org.encog.neural.networks.training.propagation.back.Backpropagation;
import org.encog.neural.networks.training.propagation.quick.QuickPropagation;
import org.encog.neural.networks.training.propagation.resilient.ResilientPropagation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    /* karakteristike:
        - duljina rijeci
        - prvo slovo ascii
        - zadnje slovo ascii
        - postotak samoglasnika u rijeci (a,e,i,o,u) x/5
        - broj samoglasnika
        - zbroj ascii vrijednosti
        - 26 neurona svaki oznacava postotak slova abecede u cijeloj rijeci
    */
    public static final String INPUT_WORDS_SET = "src/main/resources/rijeci";
    public static final String TRANSLATION_WORDS_SET = "src/main/resources/prijevodi";
    public static double[][] input;
    public static double[][] idealOutput;
    public static int neuronInput = 32;
    public static int neuronHidden = 64;
    public static int neuronOutput = 30;
    public static List<String> words = new ArrayList<>();
    public static List<String> translations = new ArrayList<>();
    public static double minLen = 0;
    public static double maxLen = 15;
    public static double minFirstLetter = 97;
    public static double maxFirstLetter = 122;
    public static double minLastLetter = 97;
    public static double maxLastLetter = 122;
    public static double minVowels = 0;
    public static double maxVowels = 15;
    public static double minAsciiSum = 0;
    public static double maxAsciiSum = 375;

    public static List<Double> letters(String word) {
        List<Character> letters = new ArrayList<>();
        List<Character> temp = new ArrayList<>();
        List<Double> solutions = new ArrayList<>();

        for (int i = 0; i < 26; i++) {
            temp.add((char) (97 + i));
        }
        for (int i = 0; i < word.length(); i++) {
            letters.add(word.charAt(i));
        }
        for (int i = 0; i < 26; i++) {
            solutions.add(0.0);
        }
        for (int i = 0; i < temp.size(); i++) {
            for (int j = 0; j < word.length(); j++) {
                if (word.charAt(j) == temp.get(i)) {
                    solutions.set(i, solutions.get(i) + 1);
                }
            }
        }
        double wordSize = word.length();
        for (int i = 0; i < 26; i++) {
            solutions.set(i, solutions.get(i) / wordSize);
        }

        return solutions;
    }

    public static double asciiSum(String word) {
        int a = 0;
        double sum = 0;
        for (int i = 0; i < word.length(); i++) {
            a = word.charAt(i) - 97;
            sum = sum + a;
        }
        return sum;
    }

    public static double vowelsCount(String word) {
        double count = 0;
        List<Character> vowelsList = List.of('a', 'e', 'i', 'o', 'u');
        for (int i = 0; i < word.length(); i++) {
            if (vowelsList.contains(word.charAt(i))) count++;
        }
        return count;
    }

    public static double vowelsPercentage(String word) {
        double count = 0;
        List<Character> letters = new ArrayList<>();
        for (int i = 0; i < word.length(); i++) {
            letters.add(word.charAt(i));
        }

        if (letters.contains('a')) {
            count++;
        }
        if (letters.contains('e')) {
            count++;
        }
        if (letters.contains('i')) {
            count++;
        }
        if (letters.contains('o')) {
            count++;
        }
        if (letters.contains('u')) {
            count++;
        }
        return count;
    }

    public static List<Double> normalize(int new_min, int new_max, double min, double max, List<Double> arr) {
        List<Double> normalizedValues = new ArrayList<>();
        for (int i = 0; i < arr.size(); i++) {
            double v = ((arr.get(i) - min) / (max - min)) * (new_max - new_min) + new_min;
            normalizedValues.add(v);
        }
        return normalizedValues;
    }

    public static Double normalizeOne(int new_min, int new_max, double min, double max, Double val) {
        return ((val - min) / (max - min)) * (new_max - new_min) + new_min;
    }

    public static double[][] inputData() throws IOException {
        String st;
        List<Double> lengths = new ArrayList<>();
        List<Double> firstLetter = new ArrayList<>();
        List<Double> lastLetter = new ArrayList<>();
        List<Double> vowelsCount = new ArrayList<>();
        List<Double> vowelsShare = new ArrayList<>();
        List<Double> asciiSum = new ArrayList<>();
        List<List<Double>> letters = new ArrayList<>();


        BufferedReader br = new BufferedReader(new FileReader(INPUT_WORDS_SET));
        while ((st = br.readLine()) != null) {
            lengths.add((double) st.length());
            firstLetter.add((double) st.charAt(0));
            lastLetter.add((double) st.charAt(st.length() - 1));
            vowelsCount.add(vowelsCount(st));
            vowelsShare.add(vowelsPercentage(st) / 5);
            asciiSum.add(asciiSum(st));
            letters.add(letters(st));
            words.add(st);
        }

        lengths = normalize(0, 1, minLen, maxLen, lengths);
        firstLetter = normalize(0, 1, minFirstLetter, maxFirstLetter, firstLetter);
        lastLetter = normalize(0, 1, minLastLetter, maxLastLetter, lastLetter);
        vowelsCount = normalize(0, 1, minVowels, maxVowels, vowelsCount);
        asciiSum = normalize(0, 1, minAsciiSum, maxAsciiSum, asciiSum);


        // duljine.size() - broj rijeci
        // n - broj karakteristika rijeci
        int n = 32;
        double[][] characteristics = new double[lengths.size()][n];
        for (int i = 0; i < lengths.size(); i++) {
            characteristics[i][0] = lengths.get(i);
            characteristics[i][1] = firstLetter.get(i);
            characteristics[i][2] = lastLetter.get(i);
            characteristics[i][3] = vowelsCount.get(i);
            characteristics[i][4] = vowelsShare.get(i);
            characteristics[i][5] = asciiSum.get(i);
            for (int j = 0; j < 26; j++) {
                characteristics[i][6 + j] = letters.get(i).get(j);
            }
        }

        return characteristics;
    }

    public static double[] getNormalizedWord(String input) {
        double[] characteristics = new double[32];
        characteristics[0] = normalizeOne(0, 1, minLen, maxLen, (double) input.length());
        characteristics[1] = normalizeOne(0, 1, minFirstLetter, maxFirstLetter, (double) input.charAt(0));
        characteristics[2] = normalizeOne(0, 1, minLastLetter, maxLastLetter,
                (double) input.charAt(input.length() - 1));
        characteristics[3] = normalizeOne(0, 1, minVowels, maxVowels, vowelsCount(input));
        characteristics[4] = vowelsPercentage(input) / 5.0;
        characteristics[5] = normalizeOne(0, 1, minAsciiSum, maxAsciiSum, asciiSum(input));

        List<Double> letterList = letters(input);
        for (int i = 0; i < 26; i++) {
            characteristics[6 + i] = letterList.get(i);
        }

        return characteristics;
    }

    public static double[][] idealOutputData(double[][] inputD) throws IOException {
        String st;
        int dataCount = 0;
        BufferedReader br = new BufferedReader(new FileReader(TRANSLATION_WORDS_SET));
        while ((st = br.readLine()) != null) {
            translations.add(st);
            dataCount++;
        }
        // inputD.length - broj elemenata u data setu,broj rijeci
        // one hot encoding
        double[][] outputValues = new double[inputD.length][dataCount];

        for (int i = 0; i < outputValues.length; i++) {
            for (int j = 0; j < dataCount; j++) {
                outputValues[i][j] = 0;
            }
        }
        int a = 1;
        int b = 0;
        for (int i = 0; i < inputD.length; i++) {
            if (a > 6) {
                a = 1;
                b++;
            }
            outputValues[i][b] = 1;
            a++;
        }

        return outputValues;

    }

    public static void main(String[] args) throws IOException {

        System.out.print("Unesite zeljenu rijec: ");
        Scanner userInput = new Scanner(System.in);
        String requiredWord = userInput.nextLine();

        double[] normalizedWord = getNormalizedWord(requiredWord);
        MLData mlDataOfRequiredWord = new BasicMLData(normalizedWord);

        input = inputData();
        idealOutput = idealOutputData(input);

        double errorLimit = 0.005;

        BasicNetwork network = new BasicNetwork();
        network.addLayer(new BasicLayer(null, true, neuronInput));
        network.addLayer(new BasicLayer(new ActivationSigmoid(), true, neuronHidden));
        network.addLayer(new BasicLayer(new ActivationSigmoid(), true, neuronHidden));
        network.addLayer(new BasicLayer(new ActivationSigmoid(), true, neuronHidden));
        network.addLayer(new BasicLayer(new ActivationSigmoid(), false, neuronOutput));
        network.getStructure().finalizeStructure();
        network.reset();

        MLDataSet mlDataSet = new BasicMLDataSet(input, idealOutput);

        MLTrain train;
        System.out.println("\nPick your training method: \n[1] QuickPropagation (default)" +
                "\n[2] Backpropagation\n[3] ResilientPropagation\n");
        int trainingMethod = userInput.nextInt();
        userInput.nextLine();

        switch (trainingMethod - 1) {
            case 1 -> train = new Backpropagation(network, mlDataSet);
            case 2 -> train = new ResilientPropagation(network, mlDataSet);
            default -> train = new QuickPropagation(network, mlDataSet);
        }

        String[] methodNameArray = train.getClass().getName().split("\\.");
        System.out.println("Using \"" + methodNameArray[methodNameArray.length-1] + "\" training method");

        System.out.println("Press enter to continue...");
        userInput.nextLine();

        int i = 1;
        int epochs = 0;
        do {
            train.iteration();
            System.out.println("Error: " + train.getError() + " Epoch: " + i);
            i++;

        } while (train.getError() > errorLimit);
        epochs = i;

        List<Double> op = new ArrayList<>();
        List<Double> id = new ArrayList<>();
        double max_op = 0;
        double max_id = 0;
        int index_op = 0;
        int index_id = 0;
        int correct = 0;

        int index_general = 0;
        for (MLDataPair pair : mlDataSet) {
            final MLData output = network.compute(pair.getInput());
            System.out.println("input=" + pair.getInput());
            System.out.println("output=" + output);
            System.out.println("ideal=" + pair.getIdeal());

            double[] results = output.getData();
            int maxInd = 0;
            for (int k = 0; k < results.length; k++) {
                if (results[k] > results[maxInd]) {
                    maxInd = k;
                }
            }

            System.out.println(words.get(index_general) + " -> " + translations.get(maxInd));
            index_general++;
            System.out.println();

            op.clear();
            id.clear();
            for (int x = 0; x < output.size(); x++) {
                op.add(output.getData(x));
            }
            for (int x = 0; x < pair.getIdeal().size(); x++) {
                id.add(pair.getIdeal().getData(x));
            }

            max_op = op.stream().mapToDouble(value -> value).max().getAsDouble();
            max_id = id.stream().mapToDouble(value -> value).max().getAsDouble();
            for (int x = 0; x < op.size(); x++) {
                if (op.get(x) == max_op) {
                    index_op = x;
                }
            }
            for (int x = 0; x < id.size(); x++) {
                if (id.get(x) == max_id) {
                    index_id = x;
                }
            }

            if (index_op == index_id) {
                correct++;
            }
        }

        final MLData result = network.compute(mlDataOfRequiredWord);
        System.out.println("Input za rijec " + requiredWord + ": " + mlDataOfRequiredWord);
        System.out.println("Output: " + result);

        double[] results = result.getData();
        int maxInd = 0;
        for (int k = 0; k < results.length; k++) {
            if (results[k] > results[maxInd]) {
                maxInd = k;
            }
        }

        System.out.println(requiredWord + " -> " + translations.get(maxInd));


        double rjesenje = correct / (double) words.size();
        System.out.println("Rjesenost: " + String.format("%.2f", rjesenje * 100.0) + "%");
        System.out.println("Broj epoha: " + epochs);
    }
}
